package by.krainet.common.dto;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

import java.time.DateTimeException;
import java.util.Date;

@Data
@Builder
@Schema(name = "Ответ регистрации")
public class SignUpResponse {

//    @Schema(description = "Username", example = "ledanbio")
//    private String username;

    @Schema(description = "Токен доступа", example = "")
    private String accessToken;

    @Schema(description = "Токен обновления", example = "")
    private String refreshToken;

//    @Schema(description = "TTL токена доступа", example = "50000")
//    private Date expirationAccess;
//
//    @Schema(description = "TTL токена обновления", example = "3000000")
//    private Integer expirationRefresh;
}
