package by.krainet.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Schema(name = "Ответ аутентификации")
public class SignInResponse {
    @Schema(description = "Токен доступа", example = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyLCJyb2xlIjoidXNlciIsImV4cCI6MTYxNjIzOTAyMn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c")
    private String accessToken;

    @Schema(description = "Токен обновления", example = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwidHlwZSI6InJlZnJlc2giLCJqdGkiOiI3YjNlZjQ1YS05YzI0LTRkZjEtYTU3ZC1hZmI4YzQ5ZjNkYzgiLCJleHAiOjE3MTY4OTYwMDB9.XsF7kQ9pL2mR4nT6vY8wZ0aB2cD4eF6gH8iJ0kL2")
    private String refreshToken;
}
